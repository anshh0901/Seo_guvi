// SEO Audit Dashboard Application
class SEOAuditApp {
    constructor() {
        this.data = {
            seo_score: 65,
            priority_issues: { high: 4, medium: 3, low: 1 },
            technical_issues: [
                {
                    issue: "Missing meta description",
                    priority: "High",
                    impact: "CTR reduction",
                    fix: "Add compelling meta description 150-160 chars"
                },
                {
                    issue: "Page load speed > 3 seconds",
                    priority: "High",
                    impact: "User experience, rankings",
                    fix: "Optimize images, enable compression"
                },
                {
                    issue: "No schema markup",
                    priority: "Medium",
                    impact: "Rich snippets opportunity",
                    fix: "Implement Article schema markup"
                },
                {
                    issue: "Internal linking opportunities",
                    priority: "Medium",
                    impact: "Page authority distribution",
                    fix: "Add contextual internal links"
                },
                {
                    issue: "Image alt tags missing",
                    priority: "Medium",
                    impact: "Accessibility, image SEO",
                    fix: "Add descriptive alt text to all images"
                }
            ],
            onpage_analysis: [
                {
                    element: "Title Tag",
                    current: "Enterprise Value vs Equity Value",
                    status: "Good",
                    recommendation: "Consider adding year or specific benefit"
                },
                {
                    element: "H1 Tag",
                    current: "Enterprise Value vs. Equity Value",
                    status: "Good",
                    recommendation: "Matches title tag well"
                },
                {
                    element: "Meta Description",
                    current: "Missing",
                    status: "Poor",
                    recommendation: "Add 150-160 char description with target keywords"
                },
                {
                    element: "URL Structure",
                    current: "/enterprise-value-vs-equity-value",
                    status: "Excellent",
                    recommendation: "Clean, keyword-rich URL"
                },
                {
                    element: "Content Length",
                    current: "~3,500 words",
                    status: "Good",
                    recommendation: "Comprehensive content length"
                }
            ],
            keyword_opportunities: [
                {
                    keyword: "enterprise value vs equity value",
                    volume: 1600,
                    difficulty: 45,
                    current_rank: "Position 8"
                },
                {
                    keyword: "enterprise value calculation",
                    volume: 2400,
                    difficulty: 50,
                    current_rank: "Not ranking"
                },
                {
                    keyword: "equity value formula",
                    volume: 1200,
                    difficulty: 40,
                    current_rank: "Position 15"
                },
                {
                    keyword: "valuation methods",
                    volume: 3200,
                    difficulty: 55,
                    current_rank: "Position 25"
                },
                {
                    keyword: "DCF valuation",
                    volume: 2800,
                    difficulty: 60,
                    current_rank: "Not ranking"
                }
            ],
            mobile_issues: [
                {
                    issue: "Mobile page speed",
                    score: "65/100",
                    priority: "High",
                    fix: "Optimize images, minify CSS/JS"
                },
                {
                    issue: "Touch elements spacing",
                    score: "Good",
                    priority: "Low",
                    fix: "No action needed"
                },
                {
                    issue: "Mobile usability",
                    score: "85/100",
                    priority: "Medium",
                    fix: "Improve button sizes"
                },
                {
                    issue: "Core Web Vitals",
                    score: "Needs improvement",
                    priority: "High",
                    fix: "Optimize LCP, FID, CLS"
                }
            ],
            content_metrics: [
                {
                    metric: "Readability Score",
                    value: "College level",
                    status: "Good",
                    target: "High school level preferred"
                },
                {
                    metric: "Content Depth",
                    value: "Comprehensive",
                    status: "Excellent",
                    target: "Maintain depth"
                },
                {
                    metric: "Keyword Density",
                    value: "2.1%",
                    status: "Good",
                    target: "1-3% range"
                },
                {
                    metric: "LSI Keywords",
                    value: "Good coverage",
                    status: "Good",
                    target: "Continue semantic coverage"
                }
            ]
        };

        this.currentSlide = 0;
        this.totalSlides = 6;
        this.isPresentationMode = false;
        this.init();
    }

    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.setupEventListeners();
                this.renderCharts();
                this.populateAuditSections();
                this.updateSlideCounter();
            });
        } else {
            this.setupEventListeners();
            this.renderCharts();
            this.populateAuditSections();
            this.updateSlideCounter();
        }
    }

    setupEventListeners() {
        // View switching
        const dashboardBtn = document.getElementById('dashboardBtn');
        const presentationBtn = document.getElementById('presentationBtn');
        const exitPresentationBtn = document.getElementById('exitPresentation');

        if (dashboardBtn) {
            dashboardBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showDashboard();
            });
        }

        if (presentationBtn) {
            presentationBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showPresentation();
            });
        }

        if (exitPresentationBtn) {
            exitPresentationBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showDashboard();
            });
        }

        // Tab navigation
        const tabButtons = document.querySelectorAll('.tab-btn');
        tabButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const tabName = e.target.getAttribute('data-tab');
                if (tabName) {
                    this.switchTab(tabName);
                }
            });
        });

        // Presentation navigation
        const prevSlideBtn = document.getElementById('prevSlide');
        const nextSlideBtn = document.getElementById('nextSlide');

        if (prevSlideBtn) {
            prevSlideBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.previousSlide();
            });
        }

        if (nextSlideBtn) {
            nextSlideBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.nextSlide();
            });
        }

        // Priority filter
        const priorityFilter = document.getElementById('priorityFilter');
        if (priorityFilter) {
            priorityFilter.addEventListener('change', (e) => {
                this.filterTechnicalIssues(e.target.value);
            });
        }

        // Keyboard navigation for presentation
        document.addEventListener('keydown', (e) => {
            if (!this.isPresentationMode) return;
            
            if (e.key === 'ArrowRight' || e.key === ' ') {
                e.preventDefault();
                this.nextSlide();
            } else if (e.key === 'ArrowLeft') {
                e.preventDefault();
                this.previousSlide();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                this.showDashboard();
            }
        });
    }

    showDashboard() {
        const dashboardView = document.getElementById('dashboardView');
        const presentationView = document.getElementById('presentationView');
        const dashboardBtn = document.getElementById('dashboardBtn');
        const presentationBtn = document.getElementById('presentationBtn');

        if (dashboardView && presentationView) {
            dashboardView.classList.remove('hidden');
            presentationView.classList.add('hidden');
            this.isPresentationMode = false;
        }

        if (dashboardBtn && presentationBtn) {
            // Update button states
            dashboardBtn.className = 'btn btn--primary';
            presentationBtn.className = 'btn btn--secondary';
        }
    }

    showPresentation() {
        const dashboardView = document.getElementById('dashboardView');
        const presentationView = document.getElementById('presentationView');
        const dashboardBtn = document.getElementById('dashboardBtn');
        const presentationBtn = document.getElementById('presentationBtn');

        if (dashboardView && presentationView) {
            dashboardView.classList.add('hidden');
            presentationView.classList.remove('hidden');
            this.isPresentationMode = true;
        }

        if (dashboardBtn && presentationBtn) {
            // Update button states
            presentationBtn.className = 'btn btn--primary';
            dashboardBtn.className = 'btn btn--secondary';
        }

        // Reset to first slide when entering presentation mode
        this.currentSlide = 0;
        this.updateSlides();
    }

    switchTab(tabName) {
        // Update tab buttons
        const tabButtons = document.querySelectorAll('.tab-btn');
        tabButtons.forEach(btn => {
            btn.classList.remove('active');
        });
        
        const activeTabBtn = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeTabBtn) {
            activeTabBtn.classList.add('active');
        }

        // Update tab content
        const tabContents = document.querySelectorAll('.tab-content');
        tabContents.forEach(content => {
            content.classList.remove('active');
        });
        
        const activeTabContent = document.getElementById(tabName);
        if (activeTabContent) {
            activeTabContent.classList.add('active');
        }
    }

    renderCharts() {
        // Add a small delay to ensure canvas elements are ready
        setTimeout(() => {
            this.renderPriorityChart();
            this.renderKeywordChart();
        }, 100);
    }

    renderPriorityChart() {
        const canvas = document.getElementById('priorityChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['High Priority', 'Medium Priority', 'Low Priority'],
                datasets: [{
                    label: 'Number of Issues',
                    data: [this.data.priority_issues.high, this.data.priority_issues.medium, this.data.priority_issues.low],
                    backgroundColor: ['#B4413C', '#FFC185', '#5D878F'],
                    borderColor: ['#B4413C', '#FFC185', '#5D878F'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    }

    renderKeywordChart() {
        const canvas = document.getElementById('keywordChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const keywords = this.data.keyword_opportunities.map(k => k.keyword.length > 20 ? k.keyword.substring(0, 20) + '...' : k.keyword);
        const volumes = this.data.keyword_opportunities.map(k => k.volume);
        const colors = this.data.keyword_opportunities.map(k => 
            k.current_rank === 'Not ranking' ? '#B4413C' : '#1FB8CD'
        );

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: keywords,
                datasets: [{
                    label: 'Monthly Search Volume',
                    data: volumes,
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    populateAuditSections() {
        this.populateTechnicalIssues();
        this.populateOnPageAnalysis();
        this.populateKeywordOpportunities();
        this.populateMobileIssues();
        this.populateContentMetrics();
    }

    populateTechnicalIssues() {
        const container = document.getElementById('technicalIssues');
        if (!container) return;

        container.innerHTML = this.data.technical_issues.map(issue => `
            <div class="issue-item" data-priority="${issue.priority}">
                <div class="issue-header">
                    <h3 class="issue-title">${issue.issue}</h3>
                    <span class="issue-priority priority-${issue.priority.toLowerCase()}">${issue.priority}</span>
                </div>
                <p class="issue-description"><strong>Impact:</strong> ${issue.impact}</p>
                <div class="issue-fix">
                    <strong>Recommended Fix:</strong> ${issue.fix}
                </div>
            </div>
        `).join('');
    }

    populateOnPageAnalysis() {
        const container = document.getElementById('onpageAnalysis');
        if (!container) return;

        container.innerHTML = this.data.onpage_analysis.map(item => `
            <div class="analysis-item">
                <div class="analysis-header">
                    <h3 class="analysis-title">${item.element}</h3>
                    <span class="status status--${this.getStatusClass(item.status)}">${item.status}</span>
                </div>
                <p class="analysis-description"><strong>Current:</strong> ${item.current}</p>
                <div class="analysis-recommendation">
                    <strong>Recommendation:</strong> ${item.recommendation}
                </div>
            </div>
        `).join('');
    }

    populateKeywordOpportunities() {
        const container = document.getElementById('keywordsOpportunities');
        if (!container) return;

        container.innerHTML = this.data.keyword_opportunities.map(keyword => `
            <div class="keyword-item">
                <div class="keyword-header">
                    <h3 class="keyword-title">${keyword.keyword}</h3>
                    <span class="status ${keyword.current_rank === 'Not ranking' ? 'status--error' : 'status--warning'}">
                        ${keyword.current_rank}
                    </span>
                </div>
                <div class="keyword-stats">
                    <div class="keyword-stat">
                        <span class="keyword-stat-label">Monthly Volume</span>
                        <span class="keyword-stat-value">${keyword.volume.toLocaleString()}</span>
                    </div>
                    <div class="keyword-stat">
                        <span class="keyword-stat-label">Difficulty</span>
                        <span class="keyword-stat-value">${keyword.difficulty}/100</span>
                    </div>
                </div>
                <div class="keyword-suggestion">
                    <strong>Opportunity:</strong> ${keyword.current_rank === 'Not ranking' ? 
                        'Target this keyword with dedicated content or optimize existing pages' : 
                        'Improve current ranking with better optimization'}
                </div>
            </div>
        `).join('');
    }

    populateMobileIssues() {
        const container = document.getElementById('mobileIssues');
        if (!container) return;

        container.innerHTML = this.data.mobile_issues.map(issue => `
            <div class="mobile-issue-item">
                <div class="mobile-header">
                    <h3 class="mobile-title">${issue.issue}</h3>
                    <span class="issue-priority priority-${issue.priority.toLowerCase()}">${issue.priority}</span>
                </div>
                <p class="mobile-description"><strong>Current Score:</strong> ${issue.score}</p>
                <div class="mobile-fix">
                    <strong>Recommended Action:</strong> ${issue.fix}
                </div>
            </div>
        `).join('');
    }

    populateContentMetrics() {
        const container = document.getElementById('contentMetrics');
        if (!container) return;

        container.innerHTML = this.data.content_metrics.map(metric => `
            <div class="content-metric-item">
                <div class="content-header">
                    <h3 class="content-title">${metric.metric}</h3>
                    <span class="status status--${this.getStatusClass(metric.status)}">${metric.status}</span>
                </div>
                <p class="content-description"><strong>Current:</strong> ${metric.value}</p>
                <div class="content-target">
                    <strong>Target:</strong> ${metric.target}
                </div>
            </div>
        `).join('');
    }

    getStatusClass(status) {
        switch (status.toLowerCase()) {
            case 'excellent': return 'success';
            case 'good': return 'success';
            case 'poor': return 'error';
            case 'needs improvement': return 'warning';
            default: return 'info';
        }
    }

    filterTechnicalIssues(priority) {
        const issues = document.querySelectorAll('#technicalIssues .issue-item');
        issues.forEach(issue => {
            if (priority === 'all' || issue.dataset.priority === priority) {
                issue.style.display = 'block';
            } else {
                issue.style.display = 'none';
            }
        });
    }

    nextSlide() {
        if (this.currentSlide < this.totalSlides - 1) {
            this.currentSlide++;
            this.updateSlides();
        }
    }

    previousSlide() {
        if (this.currentSlide > 0) {
            this.currentSlide--;
            this.updateSlides();
        }
    }

    updateSlides() {
        const slides = document.querySelectorAll('.slide');
        slides.forEach((slide, index) => {
            slide.classList.remove('active');
            if (index === this.currentSlide) {
                slide.classList.add('active');
            }
        });
        this.updateSlideCounter();
    }

    updateSlideCounter() {
        const currentSlideEl = document.getElementById('currentSlide');
        const totalSlidesEl = document.getElementById('totalSlides');
        const prevBtn = document.getElementById('prevSlide');
        const nextBtn = document.getElementById('nextSlide');

        if (currentSlideEl) currentSlideEl.textContent = this.currentSlide + 1;
        if (totalSlidesEl) totalSlidesEl.textContent = this.totalSlides;
        
        // Update navigation buttons
        if (prevBtn) prevBtn.disabled = this.currentSlide === 0;
        if (nextBtn) nextBtn.disabled = this.currentSlide === this.totalSlides - 1;
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new SEOAuditApp();
});

// Also initialize if DOM is already loaded
if (document.readyState !== 'loading') {
    new SEOAuditApp();
}